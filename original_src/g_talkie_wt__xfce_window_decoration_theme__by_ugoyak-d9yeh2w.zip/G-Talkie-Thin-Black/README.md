G-Talkie 2k16 Window decoration themes for XFCE 


## Installation:


Extract the zip file to the themes directory "/usr/share/themes/"


License: GPL-3.0+


## More Ugo Yak stuff:

Blog: https://ugoyak.wordpress.com
DeviantArt: http://ugoyak.deviantart.com
G+: https://plus.google.com/109477737867430954715
Youtube Channel: https://www.youtube.com/channel/UCynxo-TFIjL0D44bfFZW-xA